import { User } from "./user";

export const USERS: User[] = [
    {
        id: 1,
        personId: "Todor Kostadinov",
        firstName: "Todor",
        secondName: "Todorov",
        lastName: "Kostadinov",
        isAdmin: false,
        username: "todor",
        password: "password",
        position: "Software developer",
        email: "todor_kostadinov@gmail.com",
        availablePTO: 11,
        allPTO: 20
      },
];

